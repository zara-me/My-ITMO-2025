import numpy as np
import matplotlib.pyplot as plt

# Функция Ньютона для уравнения z^3 - 1
def newton_fractal(f, df, roots, xlims, ylims, resolution, max_iter=50, tol=1e-6):
    x = np.linspace(xlims[0], xlims[1], resolution)
    y = np.linspace(ylims[0], ylims[1], resolution)
    X, Y = np.meshgrid(x, y)
    Z = X + 1j * Y
    
    fractal = np.zeros(Z.shape, dtype=int)
    for _ in range(max_iter):
        Z -= f(Z) / df(Z)
        for i, root in enumerate(roots):
            converged = np.abs(Z - root) < tol
            fractal[converged] = i + 1
            Z[converged] = root  # Зафиксировать корни
    
    return fractal

# Уравнение z^3 - 1 и его производная
f = lambda z: z**3 - 1
df = lambda z: 3 * z**2
roots = [1, -0.5 + 0.5j * np.sqrt(3), -0.5 - 0.5j * np.sqrt(3)]

# Параметры изображения
xlims = [-1.5, 1.5]
ylims = [-1.5, 1.5]
resolution = 1000

# Построение фрактала
fractal = newton_fractal(f, df, roots, xlims, ylims, resolution)

# Визуализация
plt.figure(figsize=(10, 10))
colors = ['#839bb3', '#ffe0b5', '#b5b5ff']
cmap = plt.matplotlib.colors.ListedColormap(colors)
plt.imshow(fractal, extent=(*xlims, *ylims), cmap=cmap, origin="lower")
plt.colorbar(ticks=[1, 2, 3], label="Соответствие корней")
plt.title(r"$f(z) = z^3 - 1$" + "\n(Приближение: x=[-1.5, 1.5], y=[-1.5, 1.5])")
plt.xlabel("Re(z)")
plt.ylabel("Im(z)")

#a7a7d9 
#5d7491
#f4c57d

# Легенда
labels = [
    r"Корень $1$",
    r"Корень $-\frac{1}{2} + i\frac{\sqrt{3}}{2}$",
    r"Корень $-\frac{1}{2} - i\frac{\sqrt{3}}{2}$"
]
for i, (color, label) in enumerate(zip(colors, labels)):
    plt.scatter([], [], c=color, label=label)
plt.legend(title="Соответствие корней", loc="upper right")

plt.show()
