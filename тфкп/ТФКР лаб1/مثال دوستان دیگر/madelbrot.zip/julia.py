import numpy as np
import matplotlib.pyplot as plt

def julia(c, max_iter):
    def f(z):
        return z**2 + c
    return f

def julia_set(xmin, xmax, ymin, ymax, width, height, max_iter, c):
    x, y = np.linspace(xmin, xmax, width), np.linspace(ymin, ymax, height)
    C = np.array ([[complex(a, b) for a in x] for b in y])
    result = np.zeros(C.shape, dtype=int)
    for i in range(height):
        for j in range(width):
            z = C[i, j]
            n = 0
            while abs(z) <= 2 and n < max_iter :
                z = z**2 + c
                n += 1
            result [i, j] = n
    return result

xmin, xmax, ymin, ymax = -1.5, 1.5, -1.5, 1.5
width, height = 800, 800
max_iter = 700
c = complex(0.4, 0.3) # c
julia_image = julia_set(xmin, xmax, ymin, ymax, width, height, max_iter, c)
plt.figure(figsize =(10, 10))
plt.imshow(julia_image, cmap ='hot', extent =(xmin, xmax, ymin, ymax))
plt.colorbar()
plt.title(f"Множество Жулиа для c = {c}, Макс. итераций: {max_iter})")
plt.show()
