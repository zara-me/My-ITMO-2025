import numpy as np
import matplotlib.pyplot as plt
def mandelbrot(c, max_iter):
	z = 0
	n = 0
	while abs(z) <= 2 and n < max_iter :
		z = z*z + c
		n += 1
	return n

def mandelbrot_set (xmin , xmax , ymin , ymax , width , height, max_iter):
	x, y = np.linspace(xmin, xmax, width), np.linspace(ymin, ymax, height)
	C = np.array ([[complex (a, b) for a in x] for b in y])
	result = np.zeros (C.shape , dtype =int)
	qeq=height*width
	n=0
	for i in range(height):
		for j in range(width):
			result[i, j] = mandelbrot(C[i, j], max_iter)
			n+=1
		#print(n/qeq*100)
	return result

xmin, xmax, ymin, ymax = -2.0, 0.5 , -1.25 , 1.25
width, height = 800, 800
max_iter = 256
mandelbrot_image = mandelbrot_set(xmin, xmax, ymin, ymax, width, height, max_iter)
plt.figure(figsize =(10 , 10))
plt.imshow(mandelbrot_image, cmap ='hot', extent =(xmin, xmax, ymin, ymax))
plt.colorbar()
plt.title(f"Max Iterations { max_iter }")
plt.show()
