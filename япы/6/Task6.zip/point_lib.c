#include "stdio.h"

typedef struct Point {
    int x;
    int y;
} Point;


void process_point(Point* p) {
    printf("x = %d, y = %d\n", p->x, p->y);
    p->x = 6;
    p->y = 7;
}

