// gcc -fPIC -shared fast_lib.c -o fast_lib.so
// gcc -shared fast_lib.c -o fast_lib.dll

long long fib_rec(int n) {
    if (n <= 1) {
        return n;
    }
    return fib_rec(n-1) + fib_rec(n-2);
}