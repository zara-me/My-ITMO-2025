// C code => compile => exe
// C# code => compile => IL (Intermediate Language) => CLR     
// C# code (AOT compilation) => compile => exe

// 1. Visual Studio Code (SDK + extension)
// 2. Visual Studio Community (.NET)
// 3. Rider 




// OOP
public interface IAtackable
{
    public void TakeDamage(int damage);
}
