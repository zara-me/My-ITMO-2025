﻿// C code => compile => exe
// C# code => compile => IL (Intermediate Language) => CLR     
// C# code (AOT compilation) => compile => exe

// 1. Visual Studio Code (SDK + extension)
// 2. Visual Studio Community (.NET)
// 3. Rider 

Console.WriteLine("Hello, World!");

int a = 4;
var b = "ss";

Hero hero = new Warrior("name", 10, 5, 5);
Hero hero2 = new Warrior("name 2", 20, 10, 10);
Console.ForegroundColor = ConsoleColor.DarkRed;
Console.WriteLine(hero);
Console.ResetColor();
hero2.SpecialAbility(hero);
Console.WriteLine(hero);

// TODO
// 1. Создать новый класс Wizzard
// 2. Реализовать класс SpecialAbility который игнорирует защиту
// 3. Написать AutoBattler
//  3.1. Бесконечный цикл пока у кого-то HP > 0
//  3.2. Случайные характеристики
//  3.3. Случайным образом атакуют друг друга.
//  3.4. Текст в консоль разноцветный
//  3.5. Текст также выводится в файл
//  3.6. Каждую третью атакую SpecialAbility
// *3.7 Выводить звук в консоль (Console.Beep())

File.AppendAllText(Path.Combine(Environment.CurrentDirectory, "log.txt"), "tests");

var rand = new Random();
if (rand.Next(0, 100) < 50)
{

}

ConsoleOutput.Log("test", ConsoleColor.Green);
