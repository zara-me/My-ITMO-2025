// C code => compile => exe
// C# code => compile => IL (Intermediate Language) => CLR     
// C# code (AOT compilation) => compile => exe

// 1. Visual Studio Code (SDK + extension)
// 2. Visual Studio Community (.NET)
// 3. Rider 




// TODO
// 1. Создать новый класс Wizzard
// 2. Реализовать класс SpecialAbility который игнорирует защиту
// 3. Написать AutoBattler
//  3.1. Бесконечный цикл пока у кого-то HP > 0
//  3.2. Случайным образом атакуют друг друга.
//  3.3. Текст в консоль разноцветный
//  3.4. Текст также выводится в файл
//  3.5. Каждую третью атакую SpecialAbility






public class Warrior : Hero
{
    public Warrior(string name, int hp, int defense, int damage)
    : base(name, hp, defense, damage)
    {

    }

    override public void SpecialAbility(Hero Target)
    {
        Target.TakeDamage(Damage * 2);
    }
}