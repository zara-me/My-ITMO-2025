// C code => compile => exe
// C# code => compile => IL (Intermediate Language) => CLR     
// C# code (AOT compilation) => compile => exe

// 1. Visual Studio Code (SDK + extension)
// 2. Visual Studio Community (.NET)
// 3. Rider 




// OOP
abstract public class Hero : IAtackable
{
    public int HP { get; set; }
    public int Damage { get; set; }
    public int Defense { get; set; }
    public string Name { get; set; }

    public Hero(string name, int hp, int defense, int damage)
    {
        Name = name;
        Defense = defense;
        HP = hp;
        Damage = damage;
    }

    public void TakeDamage(int damage)
    {
        if (damage < 0)
            return;

        HP -= damage - Defense;
        if (HP < 0)
        {
            HP = 0;
        }
    }
    public override string ToString()
    {
        return $"[Name = {Name} HP = {HP} Defense = {Defense} Damage = {Damage}]";
    }

    public virtual void SpecialAbility(Hero target) {}
}